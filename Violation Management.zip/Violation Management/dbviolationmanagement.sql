-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2023 at 04:58 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbviolationmanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblappreoffender`
--

CREATE TABLE `tblappreoffender` (
  `appID` int(11) NOT NULL,
  `studNum` int(8) NOT NULL,
  `appFName` varchar(255) NOT NULL,
  `appConNum` varchar(11) DEFAULT NULL,
  `vioID` int(11) DEFAULT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblguidanceinfo`
--

CREATE TABLE `tblguidanceinfo` (
  `facultyID` int(11) NOT NULL,
  `facultyFname` varchar(255) NOT NULL,
  `facultyMname` varchar(255) NOT NULL,
  `facultyLname` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `facultyDept` varchar(50) NOT NULL,
  `position` varchar(255) DEFAULT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `defPosition` varchar(255) NOT NULL DEFAULT 'ADMIN'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblguidanceinfo`
--

INSERT INTO `tblguidanceinfo` (`facultyID`, `facultyFname`, `facultyMname`, `facultyLname`, `username`, `password`, `facultyDept`, `position`, `dateCreated`, `defPosition`) VALUES
(4, 'Karen', 'N.', 'Ponce', 'Karen', '123', 'BSA, BSBA, CTE, BACOM, BSPSYCH', 'Director for Guidance Counceling Office', '2023-11-14 06:52:03', 'ADMIN'),
(5, 'Mannilyn', 'B.', 'Ilagan', 'Mannilyn', '123', 'BSIT, BSCS', '', '2023-11-14 08:16:08', 'ADMIN'),
(6, 'Kristine', '', 'Yap', 'Kristine', '123', 'ACT, BSCRIM', '', '2023-11-14 08:17:23', 'ADMIN'),
(7, 'Joyce Ann', '', 'Torres', 'Joyce Ann', '123', 'BSPOLSCI', '', '2023-11-14 08:18:39', 'ADMIN'),
(8, 'Lorenzo', '', 'De Guzman', 'Lorenzo', '123', '', 'University Prepect of Discipline', '2023-11-14 08:19:32', 'ADMIN'),
(9, '', '', '', 'admin', '1234', 'admin', 'admin', '2023-11-19 15:55:35', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `tbllogs`
--

CREATE TABLE `tbllogs` (
  `logID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `defPosition` varchar(255) NOT NULL,
  `LogInTime` time DEFAULT NULL,
  `dateLogIn` date DEFAULT NULL,
  `LogOutTime` time DEFAULT NULL,
  `dateLogOut` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblstudentinfo`
--

CREATE TABLE `tblstudentinfo` (
  `studID` int(11) NOT NULL,
  `studNum` int(8) NOT NULL,
  `studFname` varchar(255) NOT NULL,
  `studMname` varchar(255) DEFAULT NULL,
  `studLname` varchar(255) NOT NULL,
  `studDept` varchar(255) NOT NULL,
  `studCourse` varchar(255) NOT NULL,
  `studYear` varchar(255) NOT NULL,
  `studSection` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `studPicture` longblob NOT NULL,
  `defPosition` varchar(255) NOT NULL DEFAULT 'STUDENT',
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbltimelog`
--

CREATE TABLE `tbltimelog` (
  `timeID` int(11) NOT NULL,
  `studNum` int(8) NOT NULL,
  `hoursToday` int(3) NOT NULL,
  `timeStart` varchar(255) NOT NULL,
  `timeEnd` varchar(255) NOT NULL,
  `dateCreated` date DEFAULT NULL,
  `vioID` int(11) DEFAULT NULL,
  `studID` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblviolationinfo`
--

CREATE TABLE `tblviolationinfo` (
  `vioID` int(11) NOT NULL,
  `studNum` int(8) NOT NULL,
  `offense` varchar(255) DEFAULT NULL,
  `violation` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `counselorName` varchar(255) NOT NULL,
  `hours` varchar(255) DEFAULT NULL,
  `consequence` varchar(255) DEFAULT NULL,
  `guidanceCounselor` varchar(255) NOT NULL,
  `endDate` varchar(255) DEFAULT NULL,
  `startDate` varchar(255) DEFAULT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblappreoffender`
--
ALTER TABLE `tblappreoffender`
  ADD PRIMARY KEY (`appID`),
  ADD KEY `vioID` (`vioID`);

--
-- Indexes for table `tblguidanceinfo`
--
ALTER TABLE `tblguidanceinfo`
  ADD PRIMARY KEY (`facultyID`);

--
-- Indexes for table `tbllogs`
--
ALTER TABLE `tbllogs`
  ADD PRIMARY KEY (`logID`);

--
-- Indexes for table `tblstudentinfo`
--
ALTER TABLE `tblstudentinfo`
  ADD PRIMARY KEY (`studID`);

--
-- Indexes for table `tbltimelog`
--
ALTER TABLE `tbltimelog`
  ADD PRIMARY KEY (`timeID`),
  ADD KEY `vioID` (`vioID`);

--
-- Indexes for table `tblviolationinfo`
--
ALTER TABLE `tblviolationinfo`
  ADD PRIMARY KEY (`vioID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblappreoffender`
--
ALTER TABLE `tblappreoffender`
  MODIFY `appID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblguidanceinfo`
--
ALTER TABLE `tblguidanceinfo`
  MODIFY `facultyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbllogs`
--
ALTER TABLE `tbllogs`
  MODIFY `logID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=382;

--
-- AUTO_INCREMENT for table `tblstudentinfo`
--
ALTER TABLE `tblstudentinfo`
  MODIFY `studID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbltimelog`
--
ALTER TABLE `tbltimelog`
  MODIFY `timeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblviolationinfo`
--
ALTER TABLE `tblviolationinfo`
  MODIFY `vioID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblappreoffender`
--
ALTER TABLE `tblappreoffender`
  ADD CONSTRAINT `tblappreoffender_ibfk_1` FOREIGN KEY (`vioID`) REFERENCES `tblviolationinfo` (`vioID`);

--
-- Constraints for table `tbltimelog`
--
ALTER TABLE `tbltimelog`
  ADD CONSTRAINT `tbltimelog_ibfk_1` FOREIGN KEY (`vioID`) REFERENCES `tblviolationinfo` (`vioID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
